from flask_app import app
from flask import render_template,flash,redirect,request
from flask_app.models.user import User

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/register",methods=["POST"])
def register():
    data = {
        "email":request.form["email"],
        "password":request.form["password"]
    }
    User.insert_user(data)
    flash("User created!")
    return redirect("/")
